import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {defineConfig} from 'vite';

// Case-insensitive path resolver to fix case mismatch issues on case-sensitive Linux servers (like Vercel)
function findCaseInsensitivePath(targetPath: string): string | null {
  const segments = targetPath.split(/[\\/]/);
  let current = '';
  
  if (path.isAbsolute(targetPath)) {
    if (process.platform === 'win32') {
      current = segments[0] + '\\';
    } else {
      current = '/';
    }
  } else {
    current = process.cwd();
  }
  
  for (let i = path.isAbsolute(targetPath) ? 1 : 0; i < segments.length; i++) {
    const segment = segments[i];
    if (!segment) continue;
    
    try {
      const children = fs.readdirSync(current);
      const match = children.find(child => child.toLowerCase() === segment.toLowerCase());
      if (match) {
        current = path.join(current, match);
      } else {
        return null;
      }
    } catch {
      return null;
    }
  }
  
  return current;
}

// Custom Vite plugin to dynamically resolve imports case-insensitively
const caseInsensitivePlugin = () => ({
  name: 'case-insensitive-resolver',
  resolveId(source: string, importer?: string) {
    // Only resolve relative, absolute, or root-relative paths
    if (source.startsWith('/') || source.startsWith('.') || path.isAbsolute(source)) {
      let absolutePath = '';
      if (source.startsWith('/')) {
        absolutePath = path.resolve(process.cwd(), source.slice(1));
      } else if (importer) {
        absolutePath = path.resolve(path.dirname(importer), source);
      } else {
        absolutePath = path.resolve(process.cwd(), source);
      }
      
      if (fs.existsSync(absolutePath)) {
        return null; // Let Vite handle it if it exists exactly
      }
      
      const resolved = findCaseInsensitivePath(absolutePath);
      if (resolved && fs.existsSync(resolved)) {
        return resolved;
      }
    }
    return null;
  }
});

// Find the actual main.tsx path (case-insensitive) for configuration fallback
const actualMainPath = findCaseInsensitivePath(path.resolve(process.cwd(), 'src/main.tsx')) || path.resolve(process.cwd(), 'src/main.tsx');

export default defineConfig(() => {
  return {
    base: '/',
    plugins: [react(), tailwindcss(), caseInsensitivePlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
        '/src/main.tsx': actualMainPath,
        './src/main.tsx': actualMainPath,
        'src/main.tsx': actualMainPath,
      },
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      rollupOptions: {
        input: {
          app: path.resolve(__dirname, 'index.html'),
        },
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
